import numpy as np
import cv2
# edge test
img = cv2.imread("./images/coin2.jpg", 0)

height = img.shape[0]
width = img.shape[1]
img = cv2.resize(img, (int(width*0.25), int(height*0.25)), interpolation=cv2.INTER_CUBIC)

img_sobel = cv2.Sobel(img, cv2.CV_16S, 1, 1)
cv2.imwrite("./outcome/img_sobel.jpg", img_sobel)

img_scharr_x = cv2.Scharr(img, cv2.CV_16S, 1, 0)
img_scharr_y = cv2.Scharr(img, cv2.CV_16S, 0, 1)
cv2.imwrite("./outcome/img_scharr_x.jpg", img_scharr_x)
cv2.imwrite("./outcome/img_scharr_y.jpg", img_scharr_y)

img_laplace = cv2.Laplacian(img, cv2.CV_8U, ksize=3)
cv2.imwrite("./outcome/img_laplace.jpg", img_laplace)

img_canny = cv2.Canny(img, 100, 200)
cv2.imwrite("./outcome/img_canny.jpg", img_canny)

# hough test

# HoughCircles
img_3 = cv2.imread("./images/hough.jpg")
img = cv2.imread("./images/hough.jpg", 0)
circles = cv2.HoughCircles(img, cv2.HOUGH_GRADIENT, 1, 20,param1=700, param2=30, minRadius=10, maxRadius=300)

if circles is not None:
    circles = np.uint16(np.around(circles))
    for i in circles[0, :]:
        center = (i[0], i[1])
        radius = i[2]
        cv2.circle(img_3, center, radius, (0, 255, 255), 3)

cv2.imwrite("./outcome/img_hough.jpg", img_3)


# HoughLines
img1_3 = cv2.imread("./images/hough1.jpg")
img1 = cv2.imread("./images/hough1.jpg", 0)
ret, img1 = cv2.threshold(img1, 150, 255, cv2.THRESH_BINARY)
img1 = cv2.Canny(img1, 50, 100)

lines = cv2.HoughLinesP(img1, 1, np.pi/180, 10, 80, 80)

for i in lines[:, 0, :]:
    cv2.line(img1_3, (i[0], i[1]), (i[2], i[3]), (0, 0, 255), 3)


cv2.imwrite("./outcome/img_hough1.jpg", img1_3)
