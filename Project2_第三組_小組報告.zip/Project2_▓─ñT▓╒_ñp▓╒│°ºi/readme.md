## How to start
```python
$ python test.py
```