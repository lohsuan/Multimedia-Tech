## How to start
Please download images in google drive we provided and put `cats_0_999` and `prediction_1990_1999` in the working directory (the same directory as `main.py`).
Images in google drive: \
[cats_0_999](https://drive.google.com/drive/folders/1lDoaCT78dJYHxFhlBZVvNSiktN6HIN_J?usp=sharing)
[prediction_1990_1999](https://drive.google.com/drive/folders/13gwUP4-we6yhHGDE3j0fnLkhz10cBYu0?usp=sharing)

```python
$ python main.py
```
