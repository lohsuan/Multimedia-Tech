## How to start
```python
$ python coin.py
$ python coin2.py
$ python floor.py
$ python fruit.py
```
